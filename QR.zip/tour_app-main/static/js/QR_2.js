// サーバーから初期データをロード
function loadInitialData() {
    fetch('/load_data')
        .then(response => response.json())
        .then(data => {
            currentPoints = data.points || 0;
            visitedStores = data.stamps || {};
            updateStampCard(); // スタンプカードを更新して表示
        })
        .catch(error => {
            console.error('初期データの読み込みに失敗しました:', error);
        });
}

loadInitialData();

// スタンプカードの情報
var stampLocations = [
    { name: '羊ヶ丘展望台', image: '/static/images/a.jpg' },
    { name: '札幌市時計台', image: '/static/images/b.jpg' },
    { name: 'さっぽろテレビ塔', image: 'C:/Users/kengo/Desktop/vscode/intern/tour_app-main/static/images/c.jpg' },
    { name: '円山動物園', image: 'C:/Users/kengo/Desktop/vscode/intern/tour_app-main/static/images/d.jpg' },
    { name: 'さっぽろテレビ塔', image: 'C:/Users/kengo/Desktop/vscode/intern/tour_app-main/static/images/e.jpg' },
    { name: '円山動物園', image: 'C:/Users/kengo/Desktop/vscode/intern/tour_app-main/static/images/f.jpg' },
    // 他の場所を追加
];

var currentPoints = 0;
var visitedStores = {};
var totalStamps = stampLocations.length;
document.getElementById('totalStamps').innerText = totalStamps;

// スタンプカードを更新して表示
function updateStampCard() {
    var stampsContainer = document.getElementById('stamps');
    stampsContainer.innerHTML = '';
    stampLocations.forEach((location, index) => {
        var stamp = document.createElement('div');
        stamp.classList.add('stamp');
        stamp.style.backgroundImage = `url(${location.image})`;

        if (visitedStores[location.name]) {
            stamp.classList.add('stamped');
        }

        stampsContainer.appendChild(stamp);
    });

    document.getElementById('points').innerText = currentPoints;
    document.getElementById('stampCount').innerText = Object.keys(visitedStores).length;
}

// QRコードを読み取ってスタンプを追加する処理
function addPoint(storeName) {
    if (!visitedStores[storeName]) {
        visitedStores[storeName] = true;
        currentPoints += 10;
        updateStampCard();

        // サーバーにデータを保存
        fetch('/update_data', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ points: currentPoints, stamps: visitedStores })
        })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    console.log('データの保存に成功しました');
                }
            })
            .catch(error => {
                console.error('データの保存に失敗しました:', error);
            });
    }
}
