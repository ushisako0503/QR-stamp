// app.js の内容（必要に応じて機能を追加します）
document.addEventListener('DOMContentLoaded', function() {
    // 必要なJavaScriptコードをここに記述します
    console.log('App.js loaded');
});
